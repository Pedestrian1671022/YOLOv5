##alert

It is difficult to rewrite img_size

## train

Step1. create ITR.yaml.

Step2. rewrite train.py.

```shell
train_loader, dataset = create_dataloader(train_path, imgsz, batch_size // WORLD_SIZE, gs, single_cls,
                                              hyp=hyp, augment=True, cache=opt.cache, rect=opt.rect, rank=RANK,
                                              workers=workers, image_weights=opt.image_weights, quad=opt.quad,
                                              prefix=colorstr('train: '))

val_loader = create_dataloader(val_path, imgsz, batch_size // WORLD_SIZE * 2, gs, single_cls,
                                       hyp=hyp, cache=None if noval else opt.cache, rect=True, rank=-1,
                                       workers=workers, pad=0.5,
                                       prefix=colorstr('val: '))[0]

```

Step3. rewrite metrics.py.

```shell
def fitness(x):
    return 2/(1/x[:, 0] + 1/x[:, 1])
# def fitness(x):
#     # Model fitness as a weighted combination of metrics
#     w = [0.0, 0.0, 0.1, 0.9]  # weights for [P, R, mAP@0.5, mAP@0.5:0.95]
#     return (x[:, :4] * w).sum(1)
```

Step4. run train.py.

```shell
python train.py --data data/ITR.yaml --cfg models/yolov5s.yaml --weights '' --batch-size 40 --device 2,3
```


## val

Step1. run val.py.

```shell
python val.py --data data/ITR.yaml --conf-thres 0.2 --iou-thres 0.05 --weights runs/train/exp/weights/best.pt --device 3
```


## detect

Step1. run detect.py.

```shell
python detect.py --source datasets/ITR/ITR_test --weights runs/train/exp/weights/best.pt --device 2 --save-txt --save-conf
```